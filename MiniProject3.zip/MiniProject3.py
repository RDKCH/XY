# -*- coding: utf-8 -*-
"""
Created on Sun Oct 01 7pm 2017

@author: Radek Chramosil

Write a Python Program to:

1. Download data for Dow Jones Index (DJIA) for the last 15 years.

2. Compute daily percentage deviations of mid- price of DJIA
    from the 200 DAY Exponential Moving average (200DEMA) of close prices.

3. Prices above the 200-DEMA would get a positive value
    while those below would get a negative value

4. Whenever price is above 200-DEMA the market is generally
    considered to be in an up-move (and vice versa).
    Graphically represent the historical deviations and
     mark out clear periods of overall bullish and
      bearish regimes in DJIA.

5. For each of these regimes, clearly fit separate linear
    trend-lines and plot it on the same graph.
6. From the difference in relative slopes of the different trend lines,
    make a note about the relative shock during market regime shifts
    (e.g. – if a long bull market gave way to a sudden correction,
     the angle between the trend-lines of the two regimes would be high and
      would correspond to a violent regime-shift)

7. Using the trend-line of the last-but-one regime,
    forecast the generic direction of price pattern for the last-regime.
     Did the projected and actual regimes match?
"""

# Import libraries
import pandas as pd
import pandas_datareader.data as web
import numpy as np
import datetime as dt
import pickle
import os

import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib
matplotlib.style.use('seaborn')


def main(bln_show_plots=False):
    """

    :return: None
    """

    # request data
    if os.path.isfile('data.p'):
        data = pickle.load(open('data.p', 'rb'))

    else:
        start = dt.datetime(2002, 10, 01)
        end = dt.datetime(2017, 10, 01)
        data = web.DataReader("^DJI", 'yahoo', start, end)
        pickle.dump(data, open('data.p', 'wb'))

    data['MidPrice'] = (data.High + data.Low)/2

    # http://pandas.pydata.org/pandas-docs/version/0.17.0/generated/pandas.ewma.html
    # http://pandas.pydata.org/pandas-docs/stable/generated/pandas.Series.ewm.html
    data['EWMA'] = pd.ewma(data.Close, com=99)

    if bln_show_plots:
        data[['MidPrice', 'EWMA']].plot()

    data['daily_deviation'] = (data.MidPrice - data.EWMA) / data.MidPrice


    return None


if __name__ == '__main__':
    main(True)