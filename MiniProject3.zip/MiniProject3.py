# -*- coding: utf-8 -*-
"""
Created on Sun Oct 01 7pm 2017

@author: Radek Chramosil

Write a Python Program to:

1. Download data for Dow Jones Index (DJIA) for the last 15 years.

2. Compute daily percentage deviations of mid- price of DJIA
    from the 200 DAY Exponential Moving average (200DEMA) of close prices.

3. Prices above the 200-DEMA would get a positive value
    while those below would get a negative value

4. Whenever price is above 200-DEMA the market is generally
    considered to be in an up-move (and vice versa).
    Graphically represent the historical deviations and
     mark out clear periods of overall bullish and
      bearish regimes in DJIA.

5. For each of these regimes, clearly fit separate linear
    trend-lines and plot it on the same graph.
    
6. From the difference in relative slopes of the different trend lines,
    make a note about the relative shock during market regime shifts
    (e.g. – if a long bull market gave way to a sudden correction,
     the angle between the trend-lines of the two regimes would be high and
      would correspond to a violent regime-shift)

7. Using the trend-line of the last-but-one regime,
    forecast the generic direction of price pattern for the last-regime.
     Did the projected and actual regimes match?
"""

# Import libraries
import pandas as pd
#import pandas_datareader.data as web
import numpy as np
import datetime as dt
import pickle
import os

#import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib
matplotlib.style.use('ggplot')

def moving_average(x, n, type='simple'):
    """
    compute an n period moving average.

    type is 'simple' | 'exponential'

    """
    x = np.asarray(x)
    if type == 'simple':
        weights = np.ones(n)
    else:
        weights = np.exp(np.linspace(-1., 0., n))

    weights /= weights.sum()

    a = np.convolve(x, weights, mode='full')[:len(x)]
    a[:n] = a[n]
    return a


def main(bln_show_plots=False):
    """

    :return: None
    """
   
    # request data
    if os.path.isfile('data.p'):
        #data = pickle.load(open('data.p', 'rb'))
        data = pd.read_csv('DJI.csv')
        data['Index'] = data.index
        data.set_index('Date', inplace=True)
        data.index = pd.to_datetime(data.index)

    else:
       # start = dt.datetime(2002, 10, 1)
       # end = dt.datetime(2017, 10, 1)
       # data = web.DataReader("^DJI", 'yahoo', start, end)
        pickle.dump(data, open('data.p', 'wb'))
        data.index = pd.to_datetime(data.index)

    bln_show_plots=False            
    data['MidPrice'] = (data.High + data.Low)/2

    # http://pandas.pydata.org/pandas-docs/version/0.17.0/generated/pandas.ewma.html
    # http://pandas.pydata.org/pandas-docs/stable/generated/pandas.Series.ewm.html
    # http://pandas.pydata.org/pandas-docs/stable/computation.html#exponentially-weighted-windows
    
    # or here:
    # http://matplotlib.org/examples/pylab_examples/finance_work2.html
    
    data['EWMA'] = pd.ewma(data.Close,span=200,freq="D")
    data['Exp'] = moving_average(data['MidPrice'].values, 200, type='exp')


    if bln_show_plots:
        data[['MidPrice', 'EWMA', 'Exp']].plot()

    # daily percentage deviations
    data['daily_deviation'] = (data.MidPrice - data.EWMA) / data.MidPrice

    # up/down trend data
    data['up_regime'] = np.where(data['daily_deviation'] > 0, 1, 0)
    data['down_regime'] = np.where(data['daily_deviation'] < 0, 1, 0)

    np_smoothed_trends = np.array((data['up_regime'], data['down_regime'])).T
    
    # smooth the trend indications - works only with this dataset
    # I define change in the trend takes 9 days
    # I had to change the first few rows manually
    
    i_current_trend = np_smoothed_trends[0,0]
    for i in range(1, len(np_smoothed_trends)):
        
        if i_current_trend != np_smoothed_trends[i,0]:
            if np_smoothed_trends[i:i+50,0].sum() > np_smoothed_trends[i:i+50,1].sum():
                np_smoothed_trends[i, 0] = 1
                np_smoothed_trends[i, 1] = 0
            else:
                np_smoothed_trends[i, 0] = 0
                np_smoothed_trends[i, 1] = 1
        
        i_current_trend = np_smoothed_trends[i, 0]
     
    np_smoothed_trends[0, 0], np_smoothed_trends[0, 1] = 1, 0
    del i, i_current_trend
    
    np_bln_regime_up = np.where(np_smoothed_trends[:,0]==1,True,False)
    np_bln_regime_down = np.where(np_smoothed_trends[:,0]==0,True,False)
        # take inverse:
        # np.where(np_bln_regime == True, False, True)
    data['up_trend_close'] = data[np_bln_regime_up]['Close']
    data['down_trend_close'] = data[np_bln_regime_down]['Close']
    
    if bln_show_plots:
        data[['up_trend_close','down_trend_close']].plot()
        
    bln_flag = True
    index_start = 0
    np_mask = np.zeros((len(np_bln_regime_up),1), dtype=np.bool)
    data['up_prediction'], data['down_prediction'] = np.nan, np.nan
    
    for i in range(0,len(np_bln_regime_up)):
        if np_bln_regime_up[i] != bln_flag:    # this is change to the trend
            index_end = i - 1
            np_mask[index_start: index_end] = True

            result = pd.ols(y=data[np_mask]['Close'],x=data[np_mask]['Index'])
    
            if bln_flag == True:  # we are in the uptrend
                data['up_prediction'].values[index_start:index_end] = result.predict(beta=result.beta, x=data.Index[index_start:index_end])               
            else:
                data['down_prediction'].values[index_start:index_end] = result.predict(beta=result.beta, x=data.Index[index_start:index_end])               
            
            np_mask[index_start: index_end] = False
            index_start = i
            bln_flag = np_bln_regime_up[i]

        if i+1 == len(np_bln_regime_up):
            index_end = i
            np_mask[index_start: index_end] = True
            result = pd.ols(y=data[np_mask]['Close'],x=data[np_mask]['Index'])
            data['up_prediction'].values[index_start:index_end] = result.predict(beta=result.beta, x=data.Index[index_start:index_end])

    data[['up_trend_close','down_trend_close','up_prediction','down_prediction']].plot(linewidth=2)   

    return None
    


if __name__ == '__main__':
    main(True)