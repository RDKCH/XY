# -*- coding: utf-8 -*-
"""
Created on Sat Sep 23 2pm 2017

@author: Radek Chramosil

1. Write a Python program to download
    the historical data of Apple Inc. (AAPL) and Microsoft Corp (MSFT) for the last 3 years.
2. Calculate the daily return for AAPL and MSFT
    and present a comparative graphical analysis.
    Use Python to print a comparative analysis of the two portfolio in terms of all the major KPIs taught in this course.
3. Calculate and graphically represent the expected return for each of the stocks.
    To do this, we have to calculate the average of the daily returns of the period being analyzed and then annualize
4. Calculate the Standard Deviation of the portfolio.
    The used stocks on the portfolio are correlated, so remember to use the appropriate Variance formula
    (reference the PDF for that formula if needed).
5. The United States Treasury Bonds are known as risk free because they always pay.
    For this analysis, a 5-year bond will be considered with an annual rate of 1.72%.
    How does the return profile of the current portfolio compare to one that is consisting solely of Treasury Bonds?
    How does the Risk Profile of the two compare?



"""

# sharp ratio
# drawdown, dd duration
# lake ratio


# Import libraries
import pandas as pd
# import pandas_datareader.data as web
import numpy as np
import datetime as dt

#import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib
matplotlib.style.use('ggplot')


def describe_series(pd_series, set_name):
    """
    Returns descriptive statistics for pandas series object

    :param pd_series: pd.S    import seaborn as snseries object - carries all data
    :param set_name: str - you can use this to set up custom name for plots
    :return: None
    """
    assert isinstance(pd_series, pd.Series), \
        "Pass in a 'pd.Series' object to 'pd_series' variable when calling 'describe_series' function"
    assert isinstance(set_name, str),\
        "Pass in a string variable to 'set_name' parameter when calling 'describe_series' function"

    np_series_values = pd_series.values

    line_size = .1
    if len(np_series_values) < 10:
        line_size = .25
    elif len(np_series_values) < 50:
        line_size = .20
    elif len(np_series_values) <= 100:
        line_size = .00125
    elif len(np_series_values) > 900:
        line_size = .0125
    elif len(np_series_values) > 400:
        line_size = .02
    elif len(np_series_values) > 150:
        line_size = .05
    elif len(np_series_values) > 120:
        line_size = .06
    elif len(np_series_values) > 100:
        line_size = .08

    fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(15, 10))

    pd_series.plot(ax=axes[0, 0], title='Close price-' + str(set_name),  marker='.', color='r')
    axes[0, 0].tick_params(labelsize=6)
    axes[0, 0].grid(b=True, which='major', color='0.75', linestyle='dotted')

    pd_series.plot(ax=axes[0, 1], kind='hist', title='Histogram-price frequecies- ' + str(set_name))
    pd_series.plot.box(ax=axes[1, 1], vert=False, title='Box Plot - ' + str(set_name))
    pd_series.plot(ax=axes[1, 0], kind='density', title='Empirical propability density - ' + str(set_name),
                   linestyle='-')
    axes[1, 0].vlines(np_series_values.mean(), line_size, 0, color='r', linestyle='dashed', label='Mean')
    axes[1, 0].vlines(np.median(np_series_values), line_size, 0, color='y', linestyle='dashed', label='Median')
    axes[1, 0].vlines(np.median(np_series_values) + np.std(np_series_values), line_size, 0, color='g',
                      linestyle='dashed', label='+Std')
    axes[1, 0].vlines(np.median(np_series_values) - np.std(np_series_values), line_size, 0, color='g',
                      linestyle='dashed', label='-Std')
    axes[1, 0].vlines(np.median(np_series_values) + 2 * np.std(np_series_values), line_size, 0, color='m',
                      linestyle='dotted', label='+2Std')
    axes[1, 0].vlines(np.median(np_series_values) - 2 * np.std(np_series_values), line_size, 0, color='m',
                      linestyle='dotted', label='-2Std')
    axes[1, 0].vlines(np.min(np_series_values), line_size, 0, color='k', linestyle='dashed', label='Min')
    axes[1, 0].vlines(np.max(np_series_values), line_size, 0, color='k', linestyle='dashed', label='Min')
    axes[1, 0].grid(b=True, which='major', color='0.75', linestyle='dotted')
    axes[1, 0].legend(['Close', 'Mean', 'Median', '+1 Std', '-1 Std', '+2 std', '-2 Std', 'Min', 'Max'],
                      loc='best')

    plt.tight_layout()
    plt.show()

    del line_size, np_series_values
    print("\nDescriptive statistics for " + set_name + " are:")
    print(pd_series.describe())

    return None


def compare_two_series(pd_df_two_series=pd.DataFrame(), set_name=''):
    """
    Prints comparison of two series. Remember to order the the frame by oldest on the top.

    Prints:
        - series over time - log scale and actual
        - returns - log scale and actual
        - cumulative returns - log scale and actual    import seaborn as sns
        - scatter matrix for the series

    :param pd_df_two_series: Data Frame with two time series
    :param set_name: Title for the plots
    :return: None but plots the comparison
    """

    assert isinstance(pd_df_two_series, pd.DataFrame), "Pass in a 'pd.DataFrame' object to 'pd_df_two_series' variable when calling 'compare_two_series' function"
    assert isinstance(set_name, str), "Pass in a string variable to 'set_name' parameter when calling 'describe_series' function"

    matplotlib.style.use('ggplot')

    fig, axes = plt.subplots(nrows=3, ncols=2, figsize=(15, 10))
    pd_df_two_series.plot(ax=axes[0, 0], title='Actual data - ' + set_name)

    np.log(pd_df_two_series).plot(ax=axes[0, 1], title='Actual data on log scale - ' + set_name,)

    df_returns = pd_df_two_series.pct_change().dropna()

    df_returns.plot(ax=axes[1, 0], title='Returns - ' + set_name, marker='.')
    df_returns += 1
    df_returns.cumprod().plot(ax=axes[1, 1], title='Cumulative returns - ' + set_name)

    df_log_returns = np.log(pd_df_two_series).diff()[1:]

    df_log_returns.plot(ax=axes[2, 0], title='Log returns - ' + set_name, marker='.')
    df_log_returns.cumsum().plot(ax=axes[2, 1], title='Log cumulative returns - ' + set_name)

    plt.tight_layout()
    plt.show()

    return None


def compare_return_two_sets(pd_df_return_set=pd.DataFrame(), set_name=''):
    """
    This create 4 plots
        - two scatter matrices using Pandas plotting functionality
        - two distribution comparisons using Seaborn package
    It will need tweaking for reuse
    It uses sequential plotting as in Matplotlib

    :param pd_df_return_set: pd.DataFrame that carries two columns of returns
    :param set_name:
    :return: None but generates plots sequentiallyix
    """

    # create the scatter_matrix
    pd.plotting.scatter_matrix(pd_df_return_set, alpha=.2, figsize=(6, 6), diagonal='hist')
    plt.suptitle('Scatter matrix for log returns - ' + set_name)
    plt.draw()

    plt.figure()
    sns.distplot(pd_df_return_set[pd_df_return_set.columns[0]].values,
                 kde_kws={"label": "KDE - " + pd_df_return_set.columns[0]},
                 hist_kws={"label": pd_df_return_set.columns[0]}
                 )

    sns.distplot(pd_df_return_set[pd_df_return_set.columns[1]].values,
                 kde_kws={"label": "KDE - " + pd_df_return_set.columns[1]},
                 hist_kws={"label": pd_df_return_set.columns[1]}
                 )
    plt.draw()
    plt.show()

    print("\nThe covariance matrix is: ")
    print(pd_df_return_set.cov())

    print("\nThe descriptive statistics for " + set_name + " returns are:\n")
    print(pd_df_return_set.describe())

    df_average_return = ((pd_df_return_set.mean() + 1) ** 252 - 1)

    print("\nThe average annualised return is (assumes 252 days in a year):")
    print((df_average_return))

    plt.figure()
    df_average_return.plot()
    plt.show()

    x = np.linspace(0, 15, 16)
    plt.figure()
    axes = plt.gca()
    axes.set_ylim([0, 0.5])
    plt.plot(x, [df_average_return.values[0].tolist()] * 16, label=pd_df_return_set.columns[0])
    plt.plot(x, [df_average_return.values[1].tolist()] * 16, label=pd_df_return_set.columns[1])
    plt.legend()
    plt.show()

    return None


def main(bln_show_plots=False):
    """
    Downloads data from yahoo and describes the series
    Calculates the requested data

    :return: None
    """

    bln_show_plots = True
    start = dt.datetime(2014, 3, 23)
    end = dt.datetime(2017, 3, 23)

    #df_aapl = web.DataReader("AAPL", 'yahoo', start, end)['Adj Close']

    #df_msft = web.DataReader("MSFT", 'yahoo', start, end)['Adj Close']

    df_aapl=pd.read_csv('AAPL.csv', index_col=0, usecols=['Date','Adj Close'])
    
    df_msft=pd.read_csv('AAPL.csv', index_col=0, usecols=['Date','Adj Close'])

    df_data = pd.concat([df_aapl, df_msft], axis=1)
    df_data.columns = ['AAPL', 'MSFT']

    df_returns = df_data.pct_change().dropna()
    df_returns['PORT'] = df_returns.sum(axis=1)/2  
    
    fl_risk_free = 0.0172
    
    # this what the return would be for 3 years
    fl_risk_free_3_year = ((fl_risk_free+1) ** 3) - 1
    
    df_portfolio = df_data.sum(axis=1)/2  

    # plot the data
    if bln_show_plots:
        describe_series(df_data.AAPL, 'AAPL')
        describe_series(df_data.MSFT, 'MSFT')

    if bln_show_plots:
        compare_two_series(df_data, 'AAPL and MSFT')

    if bln_show_plots:
        compare_return_two_sets(df_returns, 'AAPL  and MSFT')

    # calculate the variance of the portfolio
    w = .5

    fl_var_portf = w ** 2 * df_data.iloc[:, 0].values.var() + \
        w ** 2 * df_data.iloc[:, 1].values.var() + \
        2 * w ** 2 * df_data.cov().iloc[0, 1]

    print("Standard deviation of the portfolio is:" + str(np.sqrt(fl_var_portf)))

    fl_average_portoflio = ((df_portfolio.pct_change().dropna().mean() + 1) ** 252 - 1)

    fl_portf_less_rf = fl_average_portoflio - fl_risk_free_3_year

    print("\nThe annualised portfolio return is: " + str(fl_average_portoflio))
    print("\nThe excess return  of the equally weighted portfolio over risk free rate is: " + str(fl_portf_less_rf))

    
    # splitting the return for 3 years into daily returns
    fl_risk_free_daily = (fl_risk_free_3_year + 1) ** (1/len(df_returns)) - 1 
    
    # store the daily risk free into dataframe
    df_returns['rf'] = fl_risk_free_daily

    # plot
    df_returns[['PORT','rf']].plot(figsize=(12,10), marker='.')
    
    print("KPI covered are: Sharp Ratio, MDD, DDD")
    
    fl_sharp_ratio = fl_portf_less_rf / np.sqrt(fl_var_portf)
    
    print("The portoflio's Sharp ratio is: " + str(fl_sharp_ratio))

    return None


if __name__ == '__main__':
    main()
